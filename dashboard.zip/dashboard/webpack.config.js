// const HtmlWebpackPlugin = require("html-webpack-plugin");
const path = require("path");

module.exports = {
  entry: "./src/index.js",
  output: {
    path: path.join(__dirname, "public"),
    filename: "bundle.js",
    publicPath: '/'
  },

  module: {
    rules: [
      {
        loader: "babel-loader",
        test: /\.js$/,
      },
      {
        test: /\.less$/,
        use: ["style-loader", "css-loader", "less-loader"],
      },
      {
        test: /\.(png|svg|jpg|jpeg|gif|ico)$/,
        exclude: /node_modules/,
        use: ["file-loader?name=[name].[ext]"],
      },

    {
      test: /\.svg$/i,
      include: /\.*_sprite\.svg/,
      use:[

       {
         loader: 'svg-sprite-loader',
         options: {
             publicPath: './src',
         }
       },
       {
          loader: 'svgo-loader',
          options: {
          plugins: [
              { cleanupIDs: false },
          ]
       }
    }
      ]}
      // {
      //   test: /\.svg$/,
      //   use: [
      //     'svg-sprite-loader',
      //     'svgo-loader'
      //   ]
      // }
      
    ],
  },
  devServer: {
    historyApiFallback: true,
  },
  // plugins: [
  //   new HtmlWebpackPlugin({
  //     template: "/public/index.html",
  //   }),
  // ],
};
