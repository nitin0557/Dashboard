// import { Cart } from "../../container/Cart";
import {
  FETCHCARD,
  LOGIN_FAIL,
  LOGIN_LOADING,
  LOGIN_SUCCESS,
  LOGOUT,
  REMOVEPRODUCTS,
} from "../Constants";

// export const selectedProductReducer = (state = {}, action) => {
//   switch (action.type) {
//     case LOGIN:
//       return { ...state, ...action.payload };
//     case REMOVEPRODUCTS:
//       return {};
//     default:
//       return state;
//   }
// };
const init = {
  cards: {},
};
export const CardReducer = (state = init, action) => {
  console.log("state", state);
  switch (action.type) {
    
    case FETCHCARD:
      console.log("action", action);
      return { ...state, cards:action.payload };
    default:
      return state;
  }
};
export const loginReducer = (
  state = { isAuthenticated: false, result: {} ,loginLoading:false},
  action
) => {
  console.log(action);
  switch (action.type) {
    case LOGIN_SUCCESS:
      return {
        ...state,
        result:action.payload,
        isAuthenticated: true,
        // loginLoading:true

      };
    case LOGIN_FAIL:
      return {
        ...state,
        result: {},
        loginLoading:false
      };
    case LOGOUT:
      return {  loginLoading:false };
    default:
      return state;
  }
};
