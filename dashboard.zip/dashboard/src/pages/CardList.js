import React from "react";

export const Card = () => {
  return (
    <div className="home">
      <div>Card</div>
    </div>
  );
};

export const Cards = () => {
  return (
    <div className="home">
      <div>Cards</div>
    </div>
  );
};
export const Cardsheader = () => {
  return (
    <div className="home">
      <div>Cards Header</div>
    </div>
  );
};
