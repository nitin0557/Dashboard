import React from "react";

export const Dashboard = () => {
  return <div className="home">Dashboard</div>;
};

export const Analytics = () => {
  return <div className="home">Analytics</div>;
};

export const Project = () => {
  return <div className="home">Project</div>;
};

export const System = () => {
  return <div className="home">System</div>;
};

export const Monitor = () => {
  return <div className="home">Monitor</div>;
};

export const Financial = () => {
  return <div className="home">Financial</div>;
};

export const Stock = () => {
  return <div className="home">Stock</div>;
};
export const Reports = () => {
  return <div className="home">Reports</div>;
};
