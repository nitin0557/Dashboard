import React from "react";

export const Widgets = () => {
  return (
    <div className="reports">
      <div>Widgets</div>
    </div>
  );
};

export const Widgets1 = () => {
  return (
    <div className="reports">
      <div>Widgets1</div>
    </div>
  );
};

export const Widgets2 = () => {
  return (
    <div className="reports">
      <div>Widgets2</div>
    </div>
  );
};

export const Widgets3 = () => {
  return (
    <div className="reports">
      <div>Widgets3</div>
    </div>
  );
};
