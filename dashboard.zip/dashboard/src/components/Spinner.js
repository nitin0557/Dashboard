import React from 'react'
import loading from './Images/loading.gif'

const Spinner =()=> {
  
    return (
      <div className='text-center'>
          <img classaName='my-3'src={loading} alt="loading"></img>
      </div>
    )
  
}

export default Spinner