import React, { useState, useEffect } from "react";
import { fetchCard } from "../state/action-creators";
import { useSelector, useDispatch } from "react-redux";
import Icons from "./Icons";

const Progressbar4 = () => {
  const dispatch = useDispatch();
  let card = useSelector((state) => state.card.cards);
  console.log("card5", card);

  const arr = card["Card1"];
  const [header, setHeader] = useState("");
  const [icons, setIcons] = useState("");
  const [CardPart1, setCardPart1] = useState("");
  const [slider,setSlider]=useState("")
  const [CardPart2, setCardPart2] = useState("");

  useEffect(() => {
    if (
      typeof header !== "string" ||
      typeof CardPart1 !== "string" ||
      typeof CardPart2 !== "string"
    ) {
      setIcons(header.temp_icon);
      setSlider(CardPart1.slidervalues)
    } else {
      return null;
    }
  });

  useEffect(() => {
    dispatch(fetchCard());
  }, []);

  useEffect(() => {
    if (typeof arr !== "undefined") {
      if (arr.length > 0) {
        console.log("Header", arr[4]);
        const { Header, Card_Part1, Card_Part2 } = arr[3];
        console.log("Header", Header);
        setHeader(Header);
        setCardPart1(Card_Part1);
        setCardPart2(Card_Part2);
      }
    } else {
      return null;
    }
  });

  const Slider = ({done}) => {
    // const [done, setValue] = useState(0);

    const getBackgroundSize = () => {
      return {
        backgroundSize: `${(done * 100) / 10}% 100% `,
      };
    };
    

    return (
      <div className="slider">
        <input
          max={120}
          type="range"
          style={getBackgroundSize()}
          value={done}
          // onChange={(e) => setValue(e.target.valueAsNumber)}
        />
        <br />
        <span style={{ position: "relative", left: " 210px", bottom: "40px" }}>
          {done}mm
        </span>
        <br />
        <br />
      </div>
    );
  };

  return (
    <>
      <div className="card4">
        <div className="card-body4">
          <div className="d-flex">
            <div className="font"> {header.cooling_title}</div>
            <span
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Icons name={icons.icon1} color="currentColor" size={16} />
              <Icons name={icons.icon2} color="currentColor" size={25} />
            </span>
          </div>

          <div
            className="d-flex"
            style={{ borderBottom: "2px dotted rgb(232, 234, 237)" }}
          >
            <div className="font">{header.fans_title}</div>
            <Icons name={CardPart2.temp_icon} color="currentColor" size={24} />
          </div>
          <br />
          <div>
            <span style={{ color: "#96a4b5" }}>{CardPart1.left_fan}</span>
            <span>
              
              <Slider done={slider.value1} />
            </span>
            <div style={{ position: "relative", top: "18px", left: "210px" }}>
              <div className="font">{CardPart1.max_value}</div>
            </div>
          </div>
          <Icons name={CardPart2.leaficon} color="currentColor" size={16} />
          <br />
          <div className="d-flex"></div>
          <br />
          <div style={{}}>
            <span style={{ color: "#96a4b5" }}>{CardPart1.right_fan}</span>
            <span>
              
              <Slider done={slider.value2} />
            </span>
            <div style={{ position: "relative", top: "15px", left: "210px" }}>
              <div className="font">{CardPart1.max_value}</div>
            </div>
          </div>
          <svg
            style={{
              marginTop: "10px",
            }}
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            width="16"
            height="16"
          >
            
            <g>
              
              <path fill="none" d="M0 0H24V24H0z" />
              <path d="M21 3v2c0 9.627-5.373 14-12 14H7.098c.212-3.012 1.15-4.835 3.598-7.001 1.204-1.065 1.102-1.68.509-1.327-4.084 2.43-6.112 5.714-6.202 10.958L5 22H3c0-1.363.116-2.6.346-3.732C3.116 16.974 3 15.218 3 13 3 7.477 7.477 3 13 3c2 0 4 1 8 0z" />
            </g>
          </svg>
          <br />
          <div className="content-icons" style={{ margin: "6px" }}>
            <div
              style={{
                backgroundColor: "#dee2e6",
                width: "48px",
                height: "29px",
                justifyContent: "center",
                alignItems: "center",
                display: "flex",
              }}
            >
              <Icons name={icons.icon1} color="currentColor" size={16} />
            </div>
            <div>
              <Icons name={CardPart2.leaficon} color="currentColor" size={16} />
            </div>
            <div>
              <Icons
                name={CardPart2.metericon}
                color="currentColor"
                size={20}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Progressbar4;
