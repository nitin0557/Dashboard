import React from "react";
import { SidebarData } from "./SidebarData";
import SubMenu from "./SubMenu";
import img from "../components/Images/img.png";
import { useDispatch,useSelector } from "react-redux";
import { useNavigate, Link } from "react-router-dom";
import { logout } from "../state/action-creators";

const Sidebar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  // const loader = useSelector(state =>state.login.loginLoading)
  const logoutHandler = () => {
    
    localStorage.removeItem("login");
    localStorage.clear();
    dispatch(logout());
    navigate("/");
  };

  const sidetest = () => {
    return SidebarData.map((item, index) => {
      return <SubMenu item={item} key={index} />;
    });
  };

  console.log(sidetest);
  return (
    <>
      <div
        style={{
          float: "left",
          width: "250px",
          background: "white",
          height: "160px",
          position: "fixed",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div>
          {" "}
          <img
            style={{
              height: "50px",
              width: "50px",
              position: "relative",
              left: "16px",
            }}
            src={img}
            alt="profile photo"
          />
          <div style={{ color: "#97a7b6" }}>
            {" "}
            Nitin Singh <br />
            Software Engineer
          </div>
        </div>
      </div>
      <div className="Nav">
        <div className="start-icons">
          <div style={{ position: "relative", left: "9px" }}>
            {" "}
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              zoomAndPan="magnify"
              viewBox="0 0 30 30.000001"
              height="20"
              preserveAspectRatio="xMidYMid meet"
              version="1.0"
            >
              <defs>
                <clipPath id="id1">
                  <path
                    d="M 3.386719 7.164062 L 26.613281 7.164062 L 26.613281 22.40625 L 3.386719 22.40625 Z M 3.386719 7.164062 "
                    clip-rule="nonzero"
                  />
                </clipPath>
              </defs>
              <g clip-path="url(#id1)">
                <path
                  fill="rgb(0%, 0%, 0%)"
                  d="M 3.398438 22.40625 L 26.601562 22.40625 L 26.601562 19.867188 L 3.398438 19.867188 Z M 3.398438 16.054688 L 26.601562 16.054688 L 26.601562 13.515625 L 3.398438 13.515625 Z M 3.398438 7.164062 L 3.398438 9.703125 L 26.601562 9.703125 L 26.601562 7.164062 Z M 3.398438 7.164062 "
                  fill-opacity="1"
                  fill-rule="nonzero"
                />
              </g>
            </svg>
          </div>
          <div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              class="bi bi-house-door-fill"
              viewBox="0 0 16 16"
            >
              {" "}
              <path d="M6.5 14.5v-3.505c0-.245.25-.495.5-.495h2c.25 0 .5.25.5.5v3.5a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 .5-.5z" />{" "}
            </svg>
          </div>

          <div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              class="bi bi-chevron-right"
              viewBox="0 0 16 16"
            >
              {" "}
              <path
                fill-rule="evenodd"
                d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"
              />{" "}
            </svg>
          </div>
          <div>
            <span>Start</span>
          </div>

          <div>
            {" "}
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              class="bi bi-chevron-right"
              viewBox="0 0 16 16"
            >
              {" "}
              <path
                fill-rule="evenodd"
                d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"
              />{" "}
            </svg>
          </div>
        </div>

        <div className="icons">
          <div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              class="bi bi-bell"
              viewBox="0 0 16 16"
            >
              {" "}
              <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zM8 1.918l-.797.161A4.002 4.002 0 0 0 4 6c0 .628-.134 2.197-.459 3.742-.16.767-.376 1.566-.663 2.258h10.244c-.287-.692-.502-1.49-.663-2.258C12.134 8.197 12 6.628 12 6a4.002 4.002 0 0 0-3.203-3.92L8 1.917zM14.22 12c.223.447.481.801.78 1H1c.299-.199.557-.553.78-1C2.68 10.2 3 6.88 3 6c0-2.42 1.72-4.44 4.005-4.901a1 1 0 1 1 1.99 0A5.002 5.002 0 0 1 13 6c0 .88.32 4.2 1.22 6z" />{" "}
            </svg>
          </div>
          <div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              class="bi bi-envelope"
              viewBox="0 0 16 16"
            >
              {" "}
              <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2Zm13 2.383-4.708 2.825L15 11.105V5.383Zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741ZM1 11.105l4.708-2.897L1 5.383v5.722Z" />{" "}
            </svg>
          </div>
          <div>
            <Link to={`/`}>
              {" "}
              <svg
                onClick={logoutHandler}
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                class="bi bi-power"
                viewBox="0 0 16 16"
              >
                {" "}
                <path d="M7.5 1v7h1V1h-1z" />{" "}
                <path d="M3 8.812a4.999 4.999 0 0 1 2.578-4.375l-.485-.874A6 6 0 1 0 11 3.616l-.501.865A5 5 0 1 1 3 8.812z" />{" "}
              </svg>
            </Link>
          </div>
        </div>
      </div>

      <div className="layout-Sidebar">
        <div
          style={{
            position: "relative",
            bottom: "320px",
            width: "227px",
            height: "257vh",
            top: "12px",
            left: "20px",
          }}
        >
          {sidetest()}
        </div>
      </div>
    </>
  );
};

export default Sidebar;
