import "./App.less";
import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import MainContainer from "./components/MainContainer";
import Login from "./components/Login";

function App() {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/maincontainer" element={<MainContainer />} />
          <Route path="/dashboard" element={<MainContainer />} />
          <Route path="/dashboard/analytics" element={<MainContainer />} />
          <Route path="/dashboard/financial" element={<MainContainer />} />
          <Route path="/dashboard/system" element={<MainContainer />} />
          <Route path="/dashboard/stock" element={<MainContainer />} />
          <Route path="/dashboard/monitor" element={<MainContainer />} />
          <Route path="/dashboard/project" element={<MainContainer />} />
          <Route path="/dashboard/reports" element={<MainContainer />} />
          <Route path="/widgets" element={<MainContainer />} />
          <Route path="/widgets/widgets1" element={<MainContainer />} />
          <Route path="/widgets/widgets2" element={<MainContainer />} />
          <Route path="/widgets/widgets3" element={<MainContainer />} />
          <Route path="/cards" element={<MainContainer />} />
          <Route path="/cards/cards" element={<MainContainer />} />
          <Route path="/cards/cards-header" element={<MainContainer />} />
        </Routes>
      </Router>
    
    </>
  );
}

export default App;
